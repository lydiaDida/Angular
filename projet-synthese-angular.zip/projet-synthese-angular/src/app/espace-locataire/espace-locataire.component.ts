import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-espace-locataire',
  templateUrl: './espace-locataire.component.html',
  styleUrls: ['./espace-locataire.component.css']
})
export class EspaceLocataireComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
