//Interface Hebergement 

export interface Hebergement{
    id:number;
    prix: Float32Array;
    fraisDeNettoyage:Float32Array;
    fraisDeService: Float32Array;
    repertoireDePhoto: string;
    etatDeHebergement: boolean;
 
}