import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inscreption-prop',
  templateUrl: './inscreption-prop.component.html',
  styleUrls: ['./inscreption-prop.component.css']
})
export class InscreptionPropComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
