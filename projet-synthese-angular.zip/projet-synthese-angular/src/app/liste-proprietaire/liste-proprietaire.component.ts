import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-liste-proprietaire',
  templateUrl: './liste-proprietaire.component.html',
  styleUrls: ['./liste-proprietaire.component.css']
})
export class ListeProprietaireComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
