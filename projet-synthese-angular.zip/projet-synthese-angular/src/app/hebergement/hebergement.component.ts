import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hebergement',
  templateUrl: './hebergement.component.html',
  styleUrls: ['./hebergement.component.css']
})
export class HebergementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
