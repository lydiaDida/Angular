import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-liste-hebergement',
  templateUrl: './liste-hebergement.component.html',
  styleUrls: ['./liste-hebergement.component.css']
})
export class ListeHebergementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
