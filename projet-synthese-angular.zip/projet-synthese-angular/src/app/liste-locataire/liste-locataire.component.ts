import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-liste-locataire',
  templateUrl: './liste-locataire.component.html',
  styleUrls: ['./liste-locataire.component.css']
})
export class ListeLocataireComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
