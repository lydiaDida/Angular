import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inscreption',
  templateUrl: './inscreption.component.html',
  styleUrls: ['./inscreption.component.css']
})
export class InscreptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
