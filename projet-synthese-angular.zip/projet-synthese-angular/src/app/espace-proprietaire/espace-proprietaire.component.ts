import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-espace-proprietaire',
  templateUrl: './espace-proprietaire.component.html',
  styleUrls: ['./espace-proprietaire.component.css']
})
export class EspaceProprietaireComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
